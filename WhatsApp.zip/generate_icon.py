from PIL import Image, ImageDraw

def create_whatsapp_icon(output_path="icon.png"):
    # WhatsApp Green: #25D366
    bg_color = (37, 211, 102)
    size = (512, 512)
    
    # Create canvas
    img = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw rounded green background (circle)
    margin = 20
    draw.ellipse([margin, margin, size[0]-margin, size[1]-margin], fill=bg_color)
    
    # Draw stylized white chat bubble
    bubble_color = (255, 255, 255)
    
    # Main bubble circle
    b_margin = 120
    draw.ellipse([b_margin, b_margin, size[0]-b_margin, size[1]-b_margin], fill=bubble_color)
    
    # Bubble tail (triangle)
    tail_points = [
        (150, 350), # Top
        (100, 420), # Tip
        (200, 380)  # Bottom
    ]
    draw.polygon(tail_points, fill=bubble_color)
    
    # Save the icon
    img.save(output_path)
    print(f"Icon saved to {output_path}")

if __name__ == "__main__":
    create_whatsapp_icon()
